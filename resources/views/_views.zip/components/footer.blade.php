 <!-- start footer -->
 <footer class="footer-dark bg-dark-gray pt-0 pb-2 lg-pb-35px">
     <div
         class="footer-top pt-50px pb-50px sm-pt-35px sm-pb-35px border-bottom border-1 border-color-transparent-white-light">
         <div class="container">
             <div class="row align-items-center justify-content-center">
                 <!-- start footer column -->
                 <div class="col-xl-6 text-center text-xl-start lg-mb-30px sm-mb-20px">
                     <h3 class="text-white mb-5px fw-500 ls-minus-1px">
                         Get a consultation services.
                     </h3>
                     <span class="fs-20 widget-text fw-300">We will take care of your business.</span>
                 </div>
                 <!-- end footer column -->
                 <!-- start footer column -->
                 <div class="col-xl-6 text-center text-xl-end">
                     <!--   <a
                href="demo-accounting-contact.html"
                class="btn btn-extra-large btn-yellow left-icon btn-box-shadow btn-rounded text-transform-none d-inline-block align-middle me-15px xs-m-10px"
                ><i class="feather icon-feather-mail"></i>Free consultation</a
              > -->
                     <a href="tel:12345678910"
                         class="btn btn-extra-large btn-base-color left-icon btn-box-shadow btn-rounded d-inline-block align-middle xs-m-10px"><i
                             class="feather icon-feather-phone-call"></i>021-2119 1988
                     </a>
                 </div>
                 <!-- end footer column -->
             </div>
         </div>
     </div>
     <div class="container">
         <div class="row justify-content-center fs-17 fw-300 mt-5 mb-4 md-mt-45px md-mb-45px xs-mt-35px xs-mb-35px">
             <!-- start footer column -->
             <div class="col-6 col-lg-3 order-sm-1 md-mb-40px xs-mb-30px last-paragraph-no-margin">
                 <a href="demo-accounting.html" class="footer-logo mb-15px d-inline-block"><img style="max-height: 70px"
                         src="{{ URL::asset('assets') }}/images/logoputih.png" data-at2x="images/logoputih.png"
                         alt="" /></a>
                 <p class="w-85 xl-w-95 sm-w-100" style="color:#fff;">
                     PT SENA berfokus pada penyediaan layanan jasa engineering di
                     industri oil dan gas.
                 </p>
                 <div class="elements-social social-icon-style-02 mt-20px lg-mt-20px">
                     <ul class="small-icon light">
                         <li>
                             <a class="facebook" href="https://www.facebook.com/" target="_blank"><i
                                     class="fa-brands fa-facebook-f"></i></a>
                         </li>
                         <li>
                             <a class="dribbble" href="http://www.dribbble.com" target="_blank"><i
                                     class="fa-brands fa-dribbble"></i></a>
                         </li>
                         <li>
                             <a class="twitter" href="http://www.twitter.com" target="_blank"><i
                                     class="fa-brands fa-twitter"></i></a>
                         </li>
                         <li>
                             <a class="instagram" href="http://www.instagram.com" target="_blank"><i
                                     class="fa-brands fa-instagram"></i></a>
                         </li>
                     </ul>
                 </div>
             </div>
             <!-- end footer column -->
             <!-- start footer column -->
             <div class="col-6 col-lg-2 col-sm-4 xs-mb-30px order-sm-3 order-lg-2" style="color:#fff;">
                 <span class="fs-18 fw-400 d-block text-white mb-5px">Company</span>
                 <ul style="color:#fff;">
                     <li><a href="demo-accounting-company.html" style="color:#fff;">News</a></li>
                     <li><a href="demo-accounting-services.html" style="color:#fff;">Our Work</a></li>
                     <li><a href="demo-accounting-process.html" style="color:#fff;">Career</a></li>
                     <li><a href="demo-accounting-process.html" style="color:#fff;">Client</a></li>
                 </ul>
             </div>
             <!-- end footer column -->
             <!-- start footer column -->
             <div class="col-6 col-lg-2 col-sm-4 xs-mb-30px order-sm-4 order-lg-3" style="color:#fff;">
                 <span class="fs-18 fw-400 d-block text-white mb-5px">Services</span>
                 <ul>
                     <li>
                         <a href="#" style="color:#fff;">Technical Inspection </a>
                     </li>
                     <li>
                         <a href="#" style="color:#fff;">Technical Survey</a>
                     </li>
                     <li>
                         <a href="#" style="color:#fff;">Engineering Design</a>
                     </li>
                     <li><a href="#" style="color:#fff;">Consulting</a></li>
                 </ul>
             </div>
             <!-- end footer column -->
             <!-- start footer column -->
             <div class="col-6 col-lg-2 col-sm-4 xs-mb-30px order-sm-5 order-lg-4">
                 <span class="fs-18 fw-400 d-block text-white mb-5px">Kontak</span>
                 <p class="mb-5px" style="color:#fff;">Need support?</p>
                 <a href="mailto:hi@domain.com" class="text-white lh-16 d-block mb-15px">admin@admin.com</a>
                 <p class="mb-5px" style="color:#fff;">Customer care?</p>
                 <a href="tel:12345678910" class="text-white lh-16 d-block">+021-2119 1988
                 </a>
             </div>
             <!-- end footer column -->
             <!-- start footer column -->
             <div class="col-lg-3 col-sm-6 md-mb-40px xs-mb-0 order-sm-2 order-lg-5">
                 <span class="fs-18 fw-400 d-block text-white mb-5px">Alamat</span>
                 <p class="mb-20px" style="color:#fff;">
                     Komplek Perusahaan Gas Negara (PGN), Daan Mogot gang Macan Rt.3
                     Rw.5, Duri Kepa Kebon Jeruk. Kota Jakarta Barat 11510
                 </p>
             </div>
             <!-- end footer column -->
         </div>
         <div class="row align-items-center fs-16 fw-300">
             <!-- start copyright -->
             <div class="col-md-4 last-paragraph-no-margin order-2 order-md-1 text-center text-md-start">
                 <p style="color:#fff;">
                     &COPY; Copyright 2024
                     <a href="#" target="_blank" class="text-decoration-line-bottom text-white">PT SENA</a>
                 </p>
             </div>
             <!-- end copyright -->
             <!-- start footer menu -->
             <div class="col-md-8 text-md-end order-1 order-md-2 text-center text-md-end sm-mb-10px"></div>
             <!-- end footer menu -->
         </div>
     </div>
 </footer>
 <!-- end footer -->
 <!-- start sticky column -->
 <!-- <div class="sticky-wrap z-index-1 d-none d-xl-inline-block" data-animation-delay="100" data-shadow-animation="true">
            <span class="fs-15 fw-500"><i class="feather icon-feather-mail icon-small me-10px align-middle"></i>Effective business solutions? — <a href="demo-business-contact.html" class="text-decoration-line-bottom fw-600">Get started now</a></span>
        </div> -->
 <!-- end sticky column -->
 <!-- start scroll progress -->
 <div class="scroll-progress d-none d-xxl-block">
     <a href="#" class="scroll-top" aria-label="scroll">
         <span class="scroll-text">Scroll</span><span class="scroll-line"><span class="scroll-point"></span></span>
     </a>
 </div>
 <!-- end scroll progress -->
 <!-- javascript libraries -->
 <script type="text/javascript" src="{{ URL::asset('assets') }}/js/jquery.js"></script>
 <script type="text/javascript" src="{{ URL::asset('assets') }}/js/vendors.min.js"></script>
 <script type="text/javascript" src="{{ URL::asset('assets') }}/js/main.js"></script>

 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
 <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyADI_UFZwG4frendvaWoIN44eoDQfc4MO4"></script>
 <script type="text/javascript" src="{{ URL::asset('assets') }}/js/mapmarker.jquery.js"></script>

 <script type="text/javascript">
     // Use below link if you want to get latitude & longitude
     // http://www.findlatitudeandlongitude.com/find-address-from-latitude-and-longitude.php

     $(document).ready(function() {
         const icon = {
             url: "{{ URL::asset('assets') }}/image/iconmap/loc1.png", // url
             scaledSize: new google.maps.Size(25, 25), // scaled size
         };
         const icon2 = {
             url: "{{ URL::asset('assets') }}/image/iconmap/loc2.png", // url
             scaledSize: new google.maps.Size(25, 25), // scaled size
         };

         const icon3 = {
             url: "{{ URL::asset('assets') }}/image/iconmap/loc3.png", // url
             scaledSize: new google.maps.Size(25, 25), // scaled size
         };
         const icon4 = {
             url: "{{ URL::asset('assets') }}/image/iconmap/loc4.png", // url
             scaledSize: new google.maps.Size(25, 25), // scaled size
         };

         var myMarkers = {
             markers: [{
                     latitude: "-7.535770808788536",
                     longitude: "110.80470182725097",
                     icon: icon,
                     baloon_text: "<div class='infowindows'> PT PERUSAHAAN GAS NEGARA PERSERO TBK</div>",
                 },
                 {
                     latitude: "-6.4883607078910766",
                     longitude: "107.13085532768865",
                     icon: icon,
                     baloon_text: "<div class='infowindows'> PT PERUSAHAAN GAS NEGARA PERSERO TBK</div>",
                 },
                 {
                     latitude: "-2.638283066112415",
                     longitude: "114.89085572380387",
                     icon: icon,
                     baloon_text: "<div class='infowindows'> PT PERUSAHAAN GAS NEGARA PERSERO TBK</div>",
                 },
                 {
                     latitude: "-0.21482658443287508",
                     longitude: "102.0011065248742",
                     icon: icon2,
                     baloon_text: "<div class='infowindows'> PT PERUSAHAAN GAS NEGARA PERSERO TBK</div>",
                 },
                 {
                     latitude: "-1.1615051909522347",
                     longitude: "114.92588773491786",
                     icon: icon3,
                     baloon_text: "<div class='infowindows'> PT PERUSAHAAN GAS NEGARA PERSERO TBK</div>",
                 },
                 {
                     latitude: "-2.9762830118463475",
                     longitude: "119.55090446541075",
                     icon: icon4,
                     baloon_text: "<div class='infowindows'> PT PERUSAHAAN GAS NEGARA PERSERO TBK</div>",
                 },
             ],
         };

         $("#map").mapmarker({
             zoom: 5,
             center: "Indonesia",
             markers: myMarkers,
         });
     });
 </script>



 </body>

 </html>
