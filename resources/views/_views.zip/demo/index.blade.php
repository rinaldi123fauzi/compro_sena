<x-layoutsatu>
    <section class="section-dark p-0 bg-dark-gray">
        <div class="swiper lg-no-parallax magic-cursor full-screen md-h-600px sm-h-500px ipad-top-space-margin swiper-light-pagination"
            data-slider-options='{ "slidesPerView": 1, "loop": true, "parallax": true, "speed": 1000, "pagination": { "el": ".swiper-pagination-bullets", "clickable": true }, "navigation": { "nextEl": ".slider-one-slide-next-1", "prevEl": ".slider-one-slide-prev-1" }, "autoplay": { "delay": 4000, "disableOnInteraction": false },  "keyboard": { "enabled": true, "onlyInViewport": true }, "effect": "slide" }'>
            <div class="swiper-wrapper">
                <!-- start slider item -->
                <div class="swiper-slide overflow-hidden">
                    <div class="cover-background position-absolute top-0 start-0 w-100 h-100" data-swiper-parallax="500"
                        style="background-image: url('{{ URL::asset('assets') }}/images/slidersena1.jpg')">
                        <div class="opacity-light bg-gradient-sherpa-blue-black"></div>
                        <div class="container h-100" data-swiper-parallax="-500">
                            <div class="row align-items-center h-100">
                                <div class="col-xl-7 col-lg-8 col-md-10 position-relative text-white text-center text-md-start"
                                    data-anime='{ "el": "childs", "translateX": [100, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                                    <div>
                                        <span class="fs-20 opacity-6 mb-25px sm-mb-15px d-inline-block fw-300">Best
                                            solutions for your business</span>
                                    </div>
                                    <h1 class="alt-font w-90 xl-w-100 text-shadow-double-large ls-minus-2px">
                                        From Strategy
                                        <span class="fw-600">to Implementation.</span>
                                    </h1>
                                    <a href="index.html" target="_blank"
                                        class="btn btn-extra-large btn-rounded with-rounded btn-base-color btn-box-shadow box-shadow-extra-large mt-20px sm-mt-0">Get
                                        started now<span class="bg-white text-base-color"><i
                                                class="fas fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                            <div class="position-absolute bottom-minus-45px"
                                data-anime='{ "translateY": [150, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                                <span
                                    class="alt-font number text-base-color opacity-3 fs-190 fw-600 ls-minus-5px">01</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end slider item -->
                <!-- start slider item -->
                <div class="swiper-slide overflow-hidden">
                    <div class="cover-background position-absolute top-0 start-0 w-100 h-100" data-swiper-parallax="500"
                        style="background-image: url('{{ URL::asset('assets') }}/images/slidersena2.jpg')">
                        <div class="opacity-light bg-gradient-sherpa-blue-black"></div>
                        <div class="container h-100" data-swiper-parallax="-500">
                            <div class="row align-items-center h-100">
                                <div class="col-xl-7 col-lg-8 col-md-10 position-relative text-white text-center text-md-start"
                                    data-anime='{ "el": "childs", "translateX": [100, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                                    <div>
                                        <span class="fs-20 opacity-6 mb-25px sm-mb-15px d-inline-block fw-300">Best
                                            solutions for your business</span>
                                    </div>
                                    <h1 class="alt-font w-90 xl-w-100 text-shadow-double-large ls-minus-2px">
                                        From Strategy
                                        <span class="fw-600">to Implementation.</span>
                                    </h1>
                                    <a href="index.html" target="_blank"
                                        class="btn btn-extra-large btn-rounded with-rounded btn-base-color btn-box-shadow box-shadow-extra-large mt-20px sm-mt-0">Get
                                        started now<span class="bg-white text-base-color"><i
                                                class="fa-solid fa-arrow-right"></i></span></a>
                                </div>
                                <div class="position-absolute bottom-minus-45px"
                                    data-anime='{ "translateY": [150, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                                    <span
                                        class="alt-font number text-base-color opacity-3 fs-190 fw-600 ls-minus-5px">02</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end slider item -->
                <!-- start slider item -->
                <div class="swiper-slide overflow-hidden">
                    <div class="cover-background position-absolute top-0 start-0 w-100 h-100" data-swiper-parallax="500"
                        style="background-image: url('{{ URL::asset('assets') }}/images/slidersena3.jpg')">
                        <div class="opacity-light bg-gradient-sherpa-blue-black"></div>
                        <div class="container h-100" data-swiper-parallax="-500">
                            <div class="row align-items-center h-100">
                                <div class="col-xl-7 col-lg-8 col-md-10 position-relative text-white text-center text-md-start"
                                    data-anime='{ "el": "childs", "translateX": [100, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                                    <div>
                                        <span class="fs-20 opacity-6 mb-25px sm-mb-15px d-inline-block fw-300">Best
                                            solutions for your business</span>
                                    </div>
                                    <h1 class="alt-font w-90 xl-w-100 text-shadow-double-large ls-minus-2px">
                                        From Strategy
                                        <span class="fw-600">to Implementation.</span>
                                    </h1>
                                    <a href="index.html" target="_blank"
                                        class="btn btn-extra-large btn-rounded with-rounded btn-base-color btn-box-shadow box-shadow-extra-large mt-20px sm-mt-0">Get
                                        started now<span class="bg-white text-base-color"><i
                                                class="fa-solid fa-arrow-right"></i></span></a>
                                </div>
                                <div class="position-absolute bottom-minus-45px"
                                    data-anime='{ "translateY": [150, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                                    <span
                                        class="alt-font number text-base-color opacity-3 fs-190 fw-600 ls-minus-5px">03</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end slider item -->
            </div>
            <!-- start slider pagination -->
            <div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets"></div>
            <!-- end slider pagination -->
            <!-- start slider navigation -->
            <!--<div class="slider-one-slide-prev-1 icon-extra-large text-white swiper-button-prev slider-navigation-style-06 d-none d-sm-inline-block"><i class="line-icon-Arrow-OutLeft"></i></div>
                    <div class="slider-one-slide-next-1 icon-extra-large text-white swiper-button-next slider-navigation-style-06 d-none d-sm-inline-block"><i class="line-icon-Arrow-OutRight"></i></div>-->
            <!-- end slider navigation -->
        </div>
    </section>

    {{-- Section 2 --}}
    <section class="border-bottom border-color-extra-medium-gray pt-40px pb-40px overflow-hidden">
        <div class="container">
            <div class="row row-cols-1 row-cols-lg-4 row-cols-sm-2 justify-content-center align-items-center"
                data-anime='{ "el": "childs", "translateX": [-15, 0], "translateY": [15, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 200, "easing": "easeOutQuad" }'>
                <!-- start features box item -->
                <div class="col icon-with-text-style-08 md-mb-30px text-center text-sm-start">
                    <div class="feature-box feature-box-left-icon-middle d-inline-flex align-middle">
                        <div class="feature-box-icon me-10px">
                            <i class="bi bi-shield-check icon-very-medium text-base-color"></i>
                        </div>
                        <div class="feature-box-content">
                            <span class="alt-font fw-500 text-dark-gray d-block lh-26">World-class services</span>
                        </div>
                    </div>
                </div>
                <!-- end features box item -->
                <!-- start features box item -->
                <div class="col icon-with-text-style-08 md-mb-30px text-center text-sm-start">
                    <div class="feature-box feature-box-left-icon-middle d-inline-flex align-middle">
                        <div class="feature-box-icon me-10px">
                            <i class="bi bi-hourglass icon-very-medium text-base-color"></i>
                        </div>
                        <div class="feature-box-content">
                            <span class="alt-font fw-500 text-dark-gray d-block lh-26">Experienced</span>
                        </div>
                    </div>
                </div>
                <!-- end features box item -->
                <!-- start features box item -->
                <div class="col icon-with-text-style-08 xs-mb-30px text-center text-sm-start">
                    <div class="feature-box feature-box-left-icon-middle d-inline-flex align-middle">
                        <div class="feature-box-icon me-10px">
                            <i class="bi bi-award icon-very-medium text-base-color"></i>
                        </div>
                        <div class="feature-box-content">
                            <span class="alt-font fw-500 text-dark-gray d-block lh-26">Certified</span>
                        </div>
                    </div>
                </div>
                <!-- end features box item -->
                <!-- start features box item -->
                <div class="col icon-with-text-style-08 text-center text-sm-start">
                    <div class="feature-box feature-box-left-icon-middle d-inline-flex align-middle">
                        <div class="feature-box-icon me-10px">
                            <i class="bi bi-briefcase icon-very-medium text-base-color"></i>
                        </div>
                        <div class="feature-box-content">
                            <span class="alt-font fw-500 text-dark-gray d-block lh-26">Grow your business</span>
                        </div>
                    </div>
                </div>
                <!-- end features box item -->
            </div>
        </div>
    </section>


    <section class="pb-8 md-pb-17 xs-pb-28">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-xl-5 col-lg-6 col-md-9 md-mb-50px text-center text-lg-start"
                    data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                    <span
                        class="bg-solitude-blue text-uppercase fs-13 ps-25px pe-25px alt-font fw-600 text-base-color lh-40 sm-lh-55 border-radius-100px d-inline-block mb-25px">About
                        business</span>
                    <h3 class="alt-font text-dark-gray fw-600 ls-minus-1px mb-20px sm-w-85 xs-w-100 mx-auto">
                        PT Solusi Energy Nusantara (SENA)
                    </h3>
                    <p>
                        didirikan pada tahun 2015, merupakan anak perusahaan PT PGAS
                        Solution yang berfokus pada penyediaan layanan jasa engineering di
                        industri oil dan gas. Dengan keahlian dan pengalamannya yang luas,
                        SENA hadir sebagai mitra terpercaya bagi perusahaan-perusahaan di
                        sektor energi untuk menyelesaikan berbagai proyek strategis.
                    </p>
                    <div
                        class="d-flex flex-row justify-content-center justify-content-lg-start align-items-center mt-35px">
                        <div class="me-25px flex-shrink-0">
                            <div class="feature-box-content">
                                <div class="counter-number text-yellow counter fs-120 fw-700 ls-minus-3px"
                                    data-speed="2000" data-to="47"></div>
                            </div>
                        </div>
                        <div class="text-start">
                            <span
                                class="fs-20 lh-28 text-dark-gray alt-font fw-500 d-inline-block w-70 xs-w-100">Projects
                                in the <span class="text-decoration-line-bottom-medium fw-600 text-base-color">last 9
                                    years.</span></span>
                        </div>
                    </div>
                    {{-- <a href="{{ route('demo.aboutus') }}" target="_blank"
                        class="btn btn-extra-large btn-rounded with-rounded btn-base-color btn-box-shadow box-shadow-extra-large mt-20px sm-mt-0">Selengkapnya<span
                            class="bg-white text-base-color"><i class="fa-solid fa-arrow-right"></i></span></a> --}}
                </div>
                <div class="col-xl-6 col-lg-6 offset-xl-1 position-relative">
                    <div class="text-end w-80 md-w-75 ms-auto" data-animation-delay="500"
                        data-shadow-animation="true" data-bottom-top="transform: translateY(50px)"
                        data-top-bottom="transform: translateY(-50px)">
                        <img src="{{ URL::asset('assets') }}/images/tentangsenahome2.jpg" alt=""
                            class="border-radius-5px" />
                    </div>
                    <div class="w-60 md-w-50 xs-w-55 overflow-hidden position-absolute left-15px bottom-minus-50px"
                        data-shadow-animation="true" data-animation-delay="500"
                        data-bottom-top="transform: translateY(-50px)" data-top-bottom="transform: translateY(50px)">
                        <img src="{{ URL::asset('assets') }}/images/tentangsenahome.jpg" alt=""
                            class="border-radius-5px box-shadow-quadruple-large" />
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="overflow-hidden bg-regal-blue position-relative border-radius-6px lg-border-radius-0px z-index-0">
        <img src="https://craftohtml.themezaa.com/images/demo-corporate-bg-01.png"
            class="position-absolute top-minus-150px left-minus-30px z-index-minus-1"
            data-bottom-top="transform: rotate(0deg) translateY(0)"
            data-top-bottom="transform:rotate(-20deg) translateY(0)" alt="" />
        <div class="container">
            <div class="row align-items-center mb-5 sm-mb-30px text-center text-lg-start"
                data-anime='{ "el": "childs", "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay":0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <div class="col-lg-5 md-mb-30px">
                    <h3 class="text-dark-gray fw-700 ls-minus-2px mb-0" style="color: #fff">
                        Layanan Kami
                    </h3>
                </div>
                <div class="col-lg-4 offset-xl-1 last-paragraph-no-margin md-mb-30px">
                    <p>
                        Kami memberikan layanan jasa engineering di industri oil dan gas
                        yang mencakup bidang pipeline, mechanical, electrical, geodetic,
                        civil, process dan telemetry
                    </p>
                </div>
                <div class="col-xl-2 col-lg-3 d-flex justify-content-center">
                    <!-- start slider navigation -->
                    <div
                        class="slider-one-slide-prev-1 icon-small text-dark-gray swiper-button-prev slider-navigation-style-04 bg-white box-shadow-large">
                        <i class="fa-solid fa-arrow-left"></i>
                    </div>
                    <div
                        class="slider-one-slide-next-1 icon-small text-dark-gray swiper-button-next slider-navigation-style-04 bg-white box-shadow-large">
                        <i class="fa-solid fa-arrow-right"></i>
                    </div>
                    <!-- end slider navigation -->
                </div>
            </div>
            <div class="row align-items-center"
                data-anime='{ "opacity": [0,1], "duration": 600, "delay":0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <div class="col-12">
                    <div class="outside-box-right-20 sm-outside-box-right-0">
                        <div class="swiper magic-cursor slider-one-slide"
                            data-slider-options='{ "slidesPerView": 1, "spaceBetween": 30, "loop": true, "navigation": { "nextEl": ".slider-one-slide-next-1", "prevEl": ".slider-one-slide-prev-1" }, "autoplay": { "delay": 4000, "disableOnInteraction": false }, "keyboard": { "enabled": true, "onlyInViewport": true }, "breakpoints": { "1200": { "slidesPerView": 4 }, "992": { "slidesPerView": 3 }, "768": { "slidesPerView": 2 }, "320": { "slidesPerView": 1 } }, "effect": "slide" }'>
                            <div class="swiper-wrapper">
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="{{ route('demo.services') }}"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Consulting.jpg"
                                                    alt="" /></a>

                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Consulting</a>
                                                {{--  <p>
                                                    Kami memprediksi, mengendalikan kinerja dan menuntun
                                                    proyek sesuai dengan kontrak
                                                </p> --}}
                                            </div>
                                            {{-- <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Explore services</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="{{ route('demo.services') }}"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Engineering_Design.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Engineering
                                                    Design</a>
                                                {{--  <p>
                                                    Keahlian kami untuk menyusun dokumen engineering
                                                    design yang mengacu pada conceptual design
                                                </p> --}}
                                            </div>
                                            {{-- <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Explore services</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="{{ route('demo.services') }}"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Inspeksi_dan_Pengujian_Teknis.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Inspeksi
                                                    dan Pengujian Teknis</a>
                                                {{-- <p>
                                                    Keahlian kami dalam inspeksi dan pengujian teknis,
                                                    commissioning, dan pekerjaan pasca operasi.
                                                </p> --}}
                                            </div>
                                            {{-- <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Explore services</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="{{ route('demo.services') }}"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Survei_dan_Penelitian_Teknis.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Survei
                                                    dan Penelitian Teknis</a>
                                                {{-- <p>
                                                    PT Solusi Energy Nusantara memiliki keahlian dalam
                                                    bidang survei dan penelitian teknis
                                                </p> --}}
                                            </div>
                                            {{-- <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Explore services</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="{{ route('demo.services') }}"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Consulting.jpg"
                                                    alt="" /></a>

                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Consulting</a>
                                                {{-- <p>
                                                    Kami memprediksi, mengendalikan kinerja dan menuntun
                                                    proyek sesuai dengan kontrak
                                                </p> --}}
                                            </div>
                                            {{-- <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Explore services</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="{{ route('demo.services') }}"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Engineering_Design.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Engineering
                                                    Design</a>
                                                {{-- <p>
                                                    Keahlian kami untuk menyusun dokumen engineering
                                                    design yang mengacu pada conceptual design
                                                </p> --}}
                                            </div>
                                            {{-- <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Explore services</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="{{ route('demo.services') }}"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Inspeksi_dan_Pengujian_Teknis.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Inspeksi
                                                    dan Pengujian Teknis</a>
                                                {{-- <p>
                                                    Keahlian kami dalam inspeksi dan pengujian teknis,
                                                    commissioning, dan pekerjaan pasca operasi.
                                                </p> --}}
                                            </div>
                                            {{--  <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Explore services</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="{{ route('demo.services') }}"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Survei_dan_Penelitian_Teknis.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Survei
                                                    dan Penelitian Teknis</a>
                                                {{-- <p>
                                                    PT Solusi Energy Nusantara memiliki keahlian dalam
                                                    bidang survei dan penelitian teknis
                                                </p> --}}
                                            </div>
                                            {{-- <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="{{ route('demo.services') }}"
                                                    class="btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Explore services</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-60px">
                <div class="col-12 text-center">
                    {{-- <i
                        class="bi bi-envelope text-white d-inline-block align-middle icon-extra-medium me-10px md-m-5px"></i> --}}
                    <div class="fs-18 text-white d-inline-block align-middle">
                        Explore our detail service.
                        <a href="demo-corporate-contact.html" class="text-white text-decoration-line-bottom">Explore
                            now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="bg-very-light-gray">
        <div class="container">
            <div class="row justify-content-center mb-4">
                <div class="col-xl-7 col-lg-9 col-md-10 text-center">
                    <h3 class="alt-font text-dark-gray fw-600 ls-minus-1px"
                        data-anime='{ "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                        Mengapa Kami
                    </h3>
                    <p>
                        Tim engineering kami akan memandu klien kami dalam setiap tahap
                        proyek sehingga menghasilkan produk yang berkualitas
                    </p>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-lg-3 row-cols-md-2 justify-content-center"
                data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                <!-- start features box item -->
                <div class="col icon-with-text-style-07 transition-inner-all sm-mb-30px">
                    <div
                        class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                        <div class="feature-box-icon">
                            <a href="demo-accounting-services-details.html"><img
                                    src="{{ URL::asset('assets') }}/image/deal.png" class="h-95px"
                                    alt="" /></a>
                        </div>
                        <div class="feature-box-content">
                            <a href="demo-accounting-services-details.html"
                                class="d-inline-block fw-600 text-dark-gray mb-5px fs-20 ls-minus-05px">Aliansi
                                Internasional
                            </a>
                            <p class="mb-30px">
                                Kemitraan yang baik menunjukkan hasil karya kami. Aliansi yang
                                kuat dengan sebagian besar perusahaan engineering ternama di
                                dunia.
                            </p>
                        </div>
                    </div>
                </div>
                <!-- end features box item -->

                <!-- start features box item -->
                <div class="col icon-with-text-style-07 transition-inner-all sm-mb-30px">
                    <div
                        class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                        <div class="feature-box-icon">
                            <a href="demo-accounting-services-details.html"><img
                                    src="{{ URL::asset('assets') }}/image/worker.png" class="h-95px"
                                    alt="" /></a>
                        </div>
                        <div class="feature-box-content">
                            <a href="demo-accounting-services-details.html"
                                class="d-inline-block fw-600 text-dark-gray mb-5px fs-20 ls-minus-05px">Engineer
                                Berpengalaman</a>
                            <p class="mb-30px">
                                Tim Engineer kami telah melalui pelatihan berkelanjutan dan
                                sertifikasi yang komprehensif untuk menjaga standar kualitas
                                tertinggi.
                            </p>
                        </div>
                    </div>
                </div>
                <!-- end features box item -->

                <!-- start features box item -->
                <div class="col icon-with-text-style-07 transition-inner-all md-mb-30px">
                    <div
                        class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                        <div class="feature-box-icon">
                            <a href="demo-accounting-services-details.html"><img
                                    src="{{ URL::asset('assets') }}/image/portfolio.png" class="h-95px"
                                    alt="" /></a>
                        </div>
                        <div class="feature-box-content">
                            <a href="demo-accounting-services-details.html"
                                class="d-inline-block fw-600 text-dark-gray mb-5px fs-20 ls-minus-05px">Portofolio
                                Nasional</a>
                            <p class="mb-30px">
                                Kami membangun reputasi yang baik dengan menyediakan layanan
                                engineering dan bantuan teknis untuk klien kami di seluruh
                                dunia.
                            </p>
                        </div>
                    </div>
                </div>
                <!-- end features box item -->
            </div>
        </div>
    </section>




    <section class="overflow-hidden big-section">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 lg-mb-45px xs-mb-30px text-sm-start text-center">
                    <span class="fs-70 xs-fs-50 fw-700 text-dark-gray mb-0 ls-minus-2px">Hear from clients.</span>
                </div>
                <div class="col-xl-8">
                    <div class="outside-box-right-45 sm-outside-box-right-0">
                        <div class="swiper magic-cursor"
                            data-slider-options='{ "slidesPerView": 1, "spaceBetween": 60, "loop": true, "parallax": true, "speed": 1200, "pagination": { "el": ".slider-one-slide-pagination", "clickable": true, "dynamicBullets": false }, "navigation": { "nextEl": ".slider-one-slide-next-2", "prevEl": ".slider-one-slide-prev-2" }, "autoplay": { "delay": 5000, "disableOnInteraction": false }, "keyboard": { "enabled": true, "onlyInViewport": true }, "breakpoints": { "992": { "slidesPerView": 4 }, "768": { "slidesPerView": 2 }, "320": { "slidesPerView": 1 } }, "effect": "slide" }'>
                            <div class="swiper-wrapper testimonials-style-13">
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Herman miller</span>
                                    <p class="fs-22 lh-36 text-dark-gray">From the day one, Themezaa has delivered all
                                        possible outcomes as demanded. I must say that all the developers are dedicated.
                                    </p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Shoko mugikura</span>
                                    <p class="fs-22 lh-36 text-dark-gray">Theme is beautiful, although it takes some
                                        time to figure out where to edit what. But support is very quick and helpful
                                        theme.</p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Matthew taylor</span>
                                    <p class="fs-22 lh-36 text-dark-gray">They are very good with communication,
                                        addressing the need and attentively making sure the customer is fully supported.
                                    </p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Leonel mooney</span>
                                    <p class="fs-22 lh-36 text-dark-gray">What an awesome theme and support team is
                                        very kind. Every element is designed pixel perfect, so it is really a modern
                                        theme.</p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Herman miller</span>
                                    <p class="fs-22 lh-36 text-dark-gray">From the day one, Themezaa has delivered all
                                        possible outcomes as demanded. I must say that all the developers are dedicated.
                                    </p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Shoko mugikura</span>
                                    <p class="fs-22 lh-36 text-dark-gray">Theme is beautiful, although it takes some
                                        time to figure out where to edit what. But support is very quick and helpful
                                        theme.</p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Matthew taylor</span>
                                    <p class="fs-22 lh-36 text-dark-gray">They are very good with communication,
                                        addressing the need and attentively making sure the customer is fully supported.
                                    </p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Leonel mooney</span>
                                    <p class="fs-22 lh-36 text-dark-gray">What an awesome theme and support team is
                                        very kind. Every element is designed pixel perfect, so it is really a modern
                                        theme.</p>
                                </div>
                                <!-- end review item -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div
                                class="separator-line-5px w-100 bg-extra-medium-gray mt-45px mb-45px xs-mt-30px xs-mb-30px">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-4 xs-mb-30px">
                            <div class="d-flex justify-content-center justify-content-sm-start">
                                <!-- start slider navigation -->
                                <div class="slider-one-slide-prev-2 text-black swiper-button-prev slider-navigation-style-04 bg-yellow h-65px w-65px"
                                    tabindex="0" role="button" aria-label="Previous slide"><i
                                        class="fa-solid fa-arrow-left"></i></div>
                                <div class="slider-one-slide-next-2 text-black swiper-button-next slider-navigation-style-04 bg-yellow h-65px w-65px"
                                    tabindex="0" role="button" aria-label="Next slide"><i
                                        class="fa-solid fa-arrow-right"></i></div>
                                <!-- end slider navigation -->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row position-relative clients-style-08"
                data-anime='{ "translateX": [0, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                <div class="col swiper text-center feather-shadow"
                    data-slider-options='{ "slidesPerView": 2, "spaceBetween":100, "speed": 6000, "loop": true, "pagination": { "el": ".slider-four-slide-pagination-2", "clickable": false }, "allowTouchMove": false, "autoplay": { "delay":0, "disableOnInteraction": false }, "navigation": { "nextEl": ".slider-four-slide-next-2", "prevEl": ".slider-four-slide-prev-2" }, "keyboard": { "enabled": true, "onlyInViewport": true }, "breakpoints": { "1200": { "slidesPerView": 6 }, "992": { "slidesPerView": 4 }, "768": { "slidesPerView": 3 } }, "effect": "slide" }'>
                    <div class="swiper-wrapper marquee-slide">

                        <div class="swiper-slide">
                            <a href="#"><img
                                    src="https://pt-sena.co.id/images/client/16_logo_logo_client-07.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="https://pt-sena.co.id/images/client/6_logo_logo_client-03.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="https://pt-sena.co.id/images/client/7_logo_Picture2.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="https://pt-sena.co.id/images/client/5_logo_logo_client-04.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img
                                    src="https://pt-sena.co.id/images/client/18_logo_logo_client-05.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img
                                    src="https://pt-sena.co.id/images/client/17_logo_logo_client-06.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img
                                    src="https://pt-sena.co.id/images/client/16_logo_logo_client-07.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>




    <section class="position-relative overlap-height" id="news">
        <div class="container overlap-gap-section">
            <div class="row justify-content-center mb-2">
                <div class="col-xl-7 col-lg-9 col-md-10 text-center">
                    <span
                        class="bg-solitude-blue text-uppercase fs-13 ps-25px pe-25px alt-font fw-600 text-base-color lh-40 sm-lh-55 border-radius-100px d-inline-block mb-25px"
                        data-anime='{ "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>Latest
                        news</span>
                    <h3 class="alt-font text-dark-gray fw-600 ls-minus-1px"
                        data-anime='{ "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                        Tetap Update dangan Berita Terbaru Kami
                    </h3>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6 blog-standard md-mb-50px sm-mb-40px pe-25px lg-pe-15px"
                    data-anime='{ "translateY": [0, 0], "opacity": [0,1], "duration": 800, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                    <!-- start blog details  -->
                    <!-- start blog item -->
                    <div class="col-12">
                        <div class="card border-0 no-border-radius box-shadow-double-large">
                            <div class="blog-image">
                                <a href="demo-magazine-blog-single-creative.html"><img class="w-100"
                                        src="https://www.pt-sena.co.id/images/news/27_featured_image_WhatsApp_Image_2023-05-26_at_14_31_26.jpeg"
                                        alt="" /></a>
                            </div>
                            <div class="card-body p-10 bg-white sm-p-8 last-paragraph-no-margin">
                                <div class="entry-meta mb-10px fs-16 text-dark-gray">
                                    <span><a href="demo-magazine-fashion.html"
                                            class="text-dark-gray fw-500">BISNIS</a></span>
                                    <span><i class="feather icon-feather-calendar"></i><a
                                            href="demo-magazine-fashion.html" class="text-dark-gray fw-500">20 Jan
                                            2020</a></span>
                                </div>
                                <a href="{{ route('demo.singlenews') }}"
                                    class="text-dark-gray card-title mb-20px alt-font fw-600 fs-28 lh-32 d-block">Solusi
                                    Energy Nusantara (SENA) Berhasil Melampaui
                                    Target Bisnis Perseroan pada Tahun 2022</a>
                                <p class="text-medium-gray">Lorem ipsum dolor sit amet, consectetur adipiscing finibus
                                    a purus at fermentum. Praesent vitae quam sed dui mattis varius vel in nunc semper
                                    risus eget...</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- start sidebar -->
                <aside class="col-12 col-lg-6 col-md-12 ps-25px lg-ps-15px">
                    <div>
                        <div>
                            <ul class="blog-side-image blog-wrapper post-sidebar grid grid-1col xxl-grid-1col xl-grid-1col lg-grid-1col md-grid-1col sm-grid-1col xs-grid-1col"
                                data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 800, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                                <li class="grid-sizer"></li>
                                <!-- start blog item -->
                                <li class="grid-item">
                                    <div
                                        class="blog-box d-md-flex d-block flex-row h-100 overflow-hidden box-shadow-double-large">
                                        <div class="blog-image w-40 sm-w-100 cover-background sm-h-300px xs-h-200px"
                                            style="background-image: url('https://www.pt-sena.co.id/images/news/25_featured_image_IMG_0673.JPG')">
                                            <a href="demo-magazine-blog-single-creative.html"
                                                class="blog-post-image-overlay"></a>
                                        </div>
                                        <div
                                            class="blog-content w-60 sm-w-100 pt-30px pb-30px ps-40px pe-40px lg-ps-15px lg-pe-15px bg-white d-flex flex-column justify-content-center align-items-start sm-p-30px">
                                            <a href="demo-magazine-blog-single-creative.html"
                                                class="card-title text-dark-gray mb-5px fw-600 fs-19 lh-26 alt-font">SENA
                                                Adakan Buka Bersama dengan Panti Asuhan dan Yayasan
                                                Yatim Piatu</a>
                                            <div>
                                                <a href="demo-magazine-food.html"
                                                    class="d-inline-block fs-15 blog-user-name">BISNIS</a>
                                                <span
                                                    class="d-inline-block fs-14 alt-font opacity-7 ms-5px me-5px">•</span>
                                                <a href="demo-magazine-food.html" class="d-inline-block fs-15">30 Jan
                                                    2023</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <!-- end blog item -->
                                <!-- start blog item -->
                                <li class="grid-item">
                                    <div
                                        class="blog-box d-md-flex d-block flex-row h-100 overflow-hidden box-shadow-double-large">
                                        <div class="blog-image w-40 sm-w-100 cover-background sm-h-300px xs-h-200px"
                                            style="background-image: url('https://pt-sena.co.id/images/news/21_featured_image_Workshop_Penyusunan_Strategi_Bisnis_PT_Solusi_Energy_Nusantara.jpeg')">
                                            <a href="demo-magazine-blog-single-creative.html"
                                                class="blog-post-image-overlay"></a>
                                        </div>
                                        <div
                                            class="blog-content w-60 sm-w-100 pt-30px pb-30px ps-40px pe-40px lg-ps-15px lg-pe-15px bg-white d-flex flex-column justify-content-center align-items-start xs-p-35px">
                                            <a href="demo-magazine-blog-single-creative.html"
                                                class="card-title text-dark-gray mb-5px fw-600 fs-19 lh-26 alt-font">Workshop
                                                Penyusunan Strategi Bisnis Tahun 2023 PT Solusi
                                                Energy Nusantara</a>
                                            <div>
                                                <a href="demo-magazine-travel.html"
                                                    class="d-inline-block fs-15 blog-user-name">Bisnis</a>
                                                <span
                                                    class="d-inline-block fs-14 alt-font opacity-7 ms-5px me-5px">•</span>
                                                <a href="demo-magazine-travel.html" class="d-inline-block fs-15">26
                                                    Jan 2023</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <!-- end blog item -->
                                <!-- start blog item -->
                                <li class="grid-item">
                                    <div
                                        class="blog-box d-md-flex d-block flex-row h-100 overflow-hidden box-shadow-double-large">
                                        <div class="blog-image w-40 sm-w-100 cover-background sm-h-300px xs-h-200px"
                                            style="background-image: url('https://www.pt-sena.co.id/images/news/24_featured_image_kilang-pertamina-balikpapan_(1).jpg')">
                                            <a href="demo-magazine-blog-single-creative.html"
                                                class="blog-post-image-overlay"></a>
                                        </div>
                                        <div
                                            class="blog-content w-60 sm-w-100 pt-30px pb-30px ps-40px pe-40px lg-ps-15px lg-pe-15px bg-white d-flex flex-column justify-content-center align-items-start xs-p-35px">
                                            <a href="demo-magazine-blog-single-creative.html"
                                                class="card-title text-dark-gray mb-5px fw-600 fs-19 lh-26 alt-font">Kilang
                                                Pertamina Balikpapan Sepakati Kerja Sama dengan PT
                                                Solusi Energy Nusantara</a>
                                            <div>
                                                <a href="demo-magazine-music.html"
                                                    class="d-inline-block fs-15 blog-user-name">bisnis</a>
                                                <span
                                                    class="d-inline-block fs-14 alt-font opacity-7 ms-5px me-5px">•</span>
                                                <a href="demo-magazine-music.html" class="d-inline-block fs-15">24 Jan
                                                    2023</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <!-- end blog item -->
                                <!-- start blog item -->
                                {{-- <li class="grid-item">
                                    <div
                                        class="blog-box d-md-flex d-block flex-row h-100 overflow-hidden box-shadow-double-large">
                                        <div class="blog-image w-40 sm-w-100 cover-background sm-h-300px xs-h-200px"
                                            style="background-image: url('https://pt-sena.co.id/images/news/21_featured_image_Workshop_Penyusunan_Strategi_Bisnis_PT_Solusi_Energy_Nusantara.jpeg')">
                                            <a href="demo-magazine-blog-single-creative.html"
                                                class="blog-post-image-overlay"></a>
                                        </div>
                                        <div
                                            class="blog-content w-60 sm-w-100 pt-30px pb-30px ps-40px pe-40px lg-ps-15px lg-pe-15px bg-white d-flex flex-column justify-content-center align-items-start xs-p-35px">
                                            <a href="demo-magazine-blog-single-creative.html"
                                                class="card-title text-dark-gray mb-5px fw-600 fs-19 lh-26 alt-font">Workshop
                                                Penyusunan Strategi Bisnis Tahun 2023 PT Solusi
                                                Energy Nusantara</a>
                                            <div>
                                                <a href="demo-magazine-travel.html"
                                                    class="d-inline-block fs-15 blog-user-name">Bisnis</a>
                                                <span
                                                    class="d-inline-block fs-14 alt-font opacity-7 ms-5px me-5px">•</span>
                                                <a href="demo-magazine-travel.html" class="d-inline-block fs-15">26
                                                    Jan 2023</a>
                                            </div>
                                        </div>
                                    </div>
                                </li> --}}
                                <!-- end blog item -->
                            </ul>
                        </div>
                    </div>
                </aside>
                <!-- end sidebar -->
            </div>
        </div>
    </section>




</x-layoutsatu>
