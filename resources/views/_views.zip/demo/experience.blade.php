<x-layout>

    <x-slot:title>
        {{ $title }}
    </x-slot:title>
    <style>
        .map {
            padding-left: 50px;
            padding-right: 50px;
        }

        .icon1 {
            /* padding-top: 10px; */
        }

        .icon-double-large {
            width: 40px !important;
        }
    </style>
    <section class="map bg-white">
        <div>
            <div class="row justify-content-center mb-4">
                <div class="col-xl-8 col-lg-10 text-center">
                    <h3 class="text-dark-gray fw-600 ls-minus-1px"
                        data-anime='{ "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                        Current Projects
                    </h3>
                    <p>
                        All of our accomplishments throughout Petrosea’s journey are a tangible manifestation of our
                        various innovations to continuously improve and grow sustainably

                    </p>
                </div>
            </div>
            <div id="map" style="width: 100%; height: 650px"></div>
        </div>
        <div class="icon1">
            <div class="row">
                <div class="col-12 col-lg-3 md-mb-15px">
                    <div
                        class="feature-box feature-box-left-icon-middle text-start  border-radius-8px p-9 overflow-hidden last-paragraph-no-margin">
                        <div class="feature-box-icon">
                            <img class="icon-double-large" src="{{ URL::asset('assets') }}/image/iconmap/loc1.png">
                        </div>
                        <div class="feature-box-content">
                            <span class="d-inline-block fs-15 text-black fw-500 mb-5px">Engineering
                                Experience</span>

                        </div>
                        {{-- <div class="feature-box-overlay bg-cornflower-blue"></div> --}}
                    </div>
                </div>
                <div class="col-12 col-lg-3 md-mb-15px">
                    <div
                        class="feature-box feature-box-left-icon-middle text-start  border-radius-8px p-9 overflow-hidden last-paragraph-no-margin">
                        <div class="feature-box-icon">
                            <img class="icon-double-large" src="{{ URL::asset('assets') }}/image/iconmap/loc2.png">
                        </div>
                        <div class="feature-box-content">
                            <span class="d-inline-block fs-15 text-black fw-500 mb-5px">Inspection
                                Experience</span>

                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-3 md-mb-15px">
                    <div
                        class="feature-box feature-box-left-icon-middle text-start  border-radius-8px p-9 overflow-hidden last-paragraph-no-margin">
                        <div class="feature-box-icon">
                            <img class="icon-double-large" src="{{ URL::asset('assets') }}/image/iconmap/loc3.png">
                        </div>
                        <div class="feature-box-content">
                            <span class="d-inline-block fs-15 text-black fw-500 mb-5px">Survey
                                Experience</span>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-3 md-mb-15px">
                    <div
                        class="feature-box feature-box-left-icon-middle text-start  border-radius-8px p-9 overflow-hidden last-paragraph-no-margin">
                        <div class="feature-box-icon">
                            <img class="icon-double-large" src="{{ URL::asset('assets') }}/image/iconmap/loc4.png">
                        </div>
                        <div class="feature-box-content">
                            <span class="d-inline-block fs-15 text-black fw-500 mb-5px">Consultant
                                Experience</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section style="padding-top:0px !important;" class="bg-white">
        <div class="container">

            <div class="row "
                data-anime='{ "el": "childs", "translateY": [0, 0], "opacity": [0,1], "duration": 1200, "delay": 150, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <div class="col-xl-3 col-lg-4 col-md-12 tab-style-05 md-mb-30px sm-mb-20px">
                    <!-- start tab navigation -->
                    <ul class="nav nav-tabs justify-content-center border-0 text-left fw-500 fs-15 alt-font">
                        <li class="nav-item"><a data-bs-toggle="tab" href="#tab_four1"
                                class="nav-link d-flex  active"><i
                                    class="feather icon-feather-briefcase icon-extra-medium text-dark-gray"></i><span
                                    class="fs-15">Engineering
                                    Experience</span></a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab_four2"><i
                                    class="feather icon-feather-edit icon-extra-medium text-dark-gray"></i><span
                                    class="fs-15">Inspection
                                    Experience</span></a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab_four3"><i
                                    class="feather icon-feather-compass icon-extra-medium text-dark-gray"></i><span
                                    class="fs-15">Survey
                                    Experience</span></a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab_four4"><i
                                    class="feather icon-feather-globe icon-extra-medium text-dark-gray"></i><span
                                    class="fs-15">Consultant
                                    Experience</span></a></li>
                    </ul>
                    <!-- end tab navigation -->
                </div>
                <style>
                    .scroll {
                        /* Adjust the width as needed */
                        height: 400px;
                        /* Adjust the height as needed */
                        overflow: auto;
                        /* This will add scrollbars if content overflows */
                    }
                </style>
                <div class="col-xl-9 col-lg-8 col-md-12 scroll">
                    <div class="tab-content">
                        <!-- start tab content -->
                        <div class="tab-pane fade in active show" id="tab_four1">
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Pertamina Gas
                                    </span>
                                </div>
                                <div class="col-md-7">
                                    <span class="fs-15">Feed untuk Proyek Program Penggantian Pipa Minyak Wilayah
                                        Rokan</span>
                                </div>
                            </div>
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Pertamina Trans Kontinental
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="fs-15">Engineering Rektifikasi Free Span Pipa Gas Bawah Laut 28 Inch
                                        Pagerungan -
                                        Porong</span>
                                </div>
                            </div>
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019-2020</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Perusahaan Gas Negara Tbk
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="fs-15">Re Engineering untuk Persetujuan Layak Operasi (PLO)</span>
                                </div>
                            </div>
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Pertamina Gas
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="fs-15">Feed untuk Proyek Program Penggantian Pipa Minyak Wilayah
                                        Rokan</span>
                                </div>
                            </div>
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Pertamina Trans Kontinental
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="fs-15">Engineering Rektifikasi Free Span Pipa Gas Bawah Laut 28 Inch
                                        Pagerungan -
                                        Porong</span>
                                </div>
                            </div>
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019-2020</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Perusahaan Gas Negara Tbk
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="fs-15">Re Engineering untuk Persetujuan Layak Operasi (PLO)</span>
                                </div>
                            </div>
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Pertamina Gas
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="fs-15">Feed untuk Proyek Program Penggantian Pipa Minyak Wilayah
                                        Rokan</span>
                                </div>
                            </div>
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Pertamina Trans Kontinental
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="fs-15">Engineering Rektifikasi Free Span Pipa Gas Bawah Laut 28 Inch
                                        Pagerungan -
                                        Porong</span>
                                </div>
                            </div>
                            <div class="row  pb-10px pt-10px border-bottom border-color-extra-medium-gray g-0 position-relative sm-pe-40px"
                                style="">
                                <div class="col-md-2">
                                    <span class="fw-500 text-dark-gray">2019-2020</span>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-dark-gray fw-600 fs-15">PT. Perusahaan Gas Negara Tbk
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="fs-15">Re Engineering untuk Persetujuan Layak Operasi (PLO)</span>
                                </div>
                            </div>
                        </div>
                        <!-- end tab content -->
                        <!-- start tab content -->
                        <div class="tab-pane fade in" id="tab_four2">
                            <div class="row ">

                            </div>
                        </div>
                        <!-- end tab content -->
                        <!-- start tab content -->
                        <div class="tab-pane fade in" id="tab_four3">
                            <div class="row ">

                            </div>
                        </div>
                        <!-- end tab content -->
                        <!-- start tab content -->
                        <div class="tab-pane fade in" id="tab_four4">
                            <div class="row ">

                            </div>
                        </div>
                        <!-- end tab content -->
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="big-section bg-solitude-blue">
        <div class="container">
            <div class="row mb-10 align-items-center">
                <div class="col-lg-5 position-relative md-mb-20">
                    <div class="w-70 xs-w-80" data-animation-delay="50" data-shadow-animation="true">
                        <img src="{{ URL::asset('assets') }}/images/tentangsenahome2.jpg" alt=""
                            class="border-radius-8px w-100">
                    </div>
                    <div class="w-60 overflow-hidden position-absolute right-minus-15px xs-right-15px xs-w-60 bottom-minus-50px"
                        data-shadow-animation="true" data-animation-delay="250"
                        data-bottom-top="transform: translateY(50px)" data-top-bottom="transform: translateY(-50px)">
                        <img src="{{ URL::asset('assets') }}/images/tentangsenahome.jpg" alt=""
                            class="border-radius-8px w-100 box-shadow-quadruple-large" />
                    </div>
                </div>
                <div class="col-xl-5 col-lg-6 offset-lg-1"
                    data-anime='{ "el": "childs", "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay":0, "staggervalue": 300, "easing": "easeOutQuad" }'>

                    <h3 class="text-dark-gray fs-50 fw-700 ls-minus-2px">Reliable Equipment and Software</h3>

                    <div class="accordion accordion-style-02" id="accordion-style-02"
                        data-active-icon="icon-feather-chevron-up" data-inactive-icon="icon-feather-chevron-down"
                        data-anime='{ "el": "childs", "translateX": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                        <!-- start accordion item -->
                        <div class="accordion-item active-accordion">
                            <div class="accordion-header border-bottom border-color-extra-medium-gray">
                                <a href="#" data-bs-toggle="collapse" data-bs-target="#accordion-style-02-01"
                                    aria-expanded="true" data-bs-parent="#accordion-style-02">
                                    <div class="accordion-title mb-0 position-relative text-dark-gray pe-30px">
                                        <i class="feather icon-feather-chevron-up icon-extra-medium"></i><span
                                            class="fw-600 fs-18">Equipment</span>
                                    </div>
                                </a>
                            </div>
                            <div id="accordion-style-02-01" class="accordion-collapse collapse show"
                                data-bs-parent="#accordion-style-02">
                                <div
                                    class="accordion-body last-paragraph-no-margin border-bottom border-color-light-medium-gray">
                                    <p>Holiday Detector | Permanen Magnet Yoke | Gauge Wet & Dry Film Thickness |
                                        Infrared Thermography Flir T860 | Test Bench 4500 Psig
                                    </p>
                                </div>
                            </div>
                        </div>
                        <!-- end accordion item -->
                        <!-- start accordion item -->
                        <div class="accordion-item">
                            <div class="accordion-header border-bottom border-color-extra-medium-gray">
                                <a href="#" data-bs-toggle="collapse" data-bs-target="#accordion-style-02-02"
                                    aria-expanded="false" data-bs-parent="#accordion-style-02">
                                    <div class="accordion-title mb-0 position-relative text-dark-gray pe-30px">
                                        <i class="feather icon-feather-chevron-down icon-extra-medium"></i><span
                                            class="fw-600 fs-18">Software</span>
                                    </div>
                                </a>
                            </div>
                            <div id="accordion-style-02-02" class="accordion-collapse collapse"
                                data-bs-parent="#accordion-style-02">
                                <div
                                    class="accordion-body last-paragraph-no-margin border-bottom border-color-light-medium-gray">
                                    <p>HYSYS | PV Elite | STAAD Pro | Unisim | PHAST | Instrucalc | AutoCAD | CAESAR II
                                        | ETAP | Arc Gis</p>
                                </div>
                            </div>
                        </div>
                        <!-- end accordion item -->
                        <!-- start accordion item -->

                        <!-- end accordion item -->
                        <!-- start accordion item -->

                        <!-- end accordion item -->
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-layout>
