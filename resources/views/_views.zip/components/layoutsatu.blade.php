<x-header></x-header>



{{ $slot }}
<x-footer></x-footer>
