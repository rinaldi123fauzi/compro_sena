<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <title>PT Sena</title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="ThemeZaa" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />

    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/favicon.png" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png" />
    <!-- google fonts preconnect -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <!-- style sheets and font icons -->
    <link rel="stylesheet" href="{{ URL::asset('assets') }}/css/vendors.min.css" />
    <link rel="stylesheet" href="{{ URL::asset('assets') }}/css/icon.min.css" />
    <link rel="stylesheet" href="{{ URL::asset('assets') }}/css/style.css" />
    <link rel="stylesheet" href="{{ URL::asset('assets') }}/css/responsive.css" />
    <link rel="stylesheet" href="{{ URL::asset('assets') }}/demos/business/business.css" />
</head>

<body data-mobile-nav-style="classic">
    <header class="header-with-topbar">
        <nav class="navbar navbar-expand-lg header-transparent bg-transparent header-reverse" data-header-hover="light">
            <div class="container-fluid">
                <div class="col-auto col-xxl-3 col-lg-2 me-lg-0 me-auto">

                    <a class="navbar-brand" href="{{ route('demo.index') }}">
                        <img src="{{ URL::asset('assets') }}/images/logosena.png"
                            data-at2x="{{ URL::asset('assets') }}/images/logosena.png" alt=""
                            class="default-logo">
                        <img src="{{ URL::asset('assets') }}/images/logosena.png"
                            data-at2x="{{ URL::asset('assets') }}/images/logosena.png" alt="" class="alt-logo">
                        <img src="{{ URL::asset('assets') }}/images/logosena.png"
                            data-at2x="{{ URL::asset('assets') }}/images/logosena.png" alt=""
                            class="mobile-logo">
                    </a>

                </div>
                <div class="col-auto menu-order position-static">
                    <button class="navbar-toggler float-start" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarNav" aria-controls="navbarNav" aria-label="Toggle navigation">
                        <span class="navbar-toggler-line"></span>
                        <span class="navbar-toggler-line"></span>
                        <span class="navbar-toggler-line"></span>
                        <span class="navbar-toggler-line"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav fw-600">
                            <li class="nav-item">
                                <a href="{{ route('demo.index') }}" class="nav-link">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="#news" class="nav-link">News</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('demo.aboutus') }}" class="nav-link">About Us</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('demo.services') }}" class="nav-link">Service</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('demo.contactus') }}" class="nav-link">Contact Us</a>
                            </li>
                            {{-- <li class="nav-item">
                                <a href="demo-accounting-company.html" class="nav-link">Client</a>
                            </li> --}}
                            <li class="nav-item">
                                <a href="{{ route('demo.experience') }}" class="nav-link">Experience</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">Portal</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-auto col-xxl-3 col-lg-2 text-end d-none d-sm-flex">
                    <div class="header-icon">

                        <div class="header-button"><a href="demo-business-contact.html"
                                style="background-color: #fff; color: #000;"
                                class="btn btn-very-small btn-transparent-white-light btn-rounded">Career</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>
