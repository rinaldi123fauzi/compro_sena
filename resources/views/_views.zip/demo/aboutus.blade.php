<x-layout>
    <style>
        .fs-15 {
            font-size: 13px;
        }

        .bg-base-color {
            background-color: #ee9f27;
        }
    </style>
    <x-slot:title>
        {{ $title }}
    </x-slot:title>




    <section id="down-section">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-5 col-md-10 position-relative z-index-1 md-mb-40px">
                    <div class="atropos" data-atropos>
                        <div class="atropos-scale"
                            data-anime='{ "translate": [0, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                            <div class="atropos-rotate">
                                <div class="atropos-inner">
                                    <div data-atropos-offset="3">
                                        <img src="{{ URL::asset('assets') }}/images/tentangsenahome2.jpg"
                                            class="border-radius-6px w-100" alt="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        class="absolute-middle-right md-absolute-middle-center right-minus-45px md-right-auto d-inline-block text-center z-index-9">
                        <a href="#"
                            class="bg-white box-shadow-extra-large rounded-circle video-icon-box video-icon-extra-large popup-youtube d-inline-block"
                            data-anime='{ "translate": [0, 0], "scale": [0,1], "duration": 1000, "delay": 300, "staggervalue": 300, "easing": "easeOutBack" }'>
                            <span>
                                <span class="video-icon bg-white">
                                    <i class="fa-solid fa-play text-base-color"></i>
                                    <span class="video-icon-sonar">
                                        <span class="video-icon-sonar-bfr bg-base-color opacity-9"></span>
                                    </span>
                                </span>
                            </span>
                        </a>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-6 offset-lg-1 col-md-9 ps-6 text-center text-lg-start lg-ps-15px"
                    data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                    <span
                        class="bg-solitude-blue text-uppercase fs-13 ps-25px pe-25px alt-font fw-600 text-base-color lh-40 sm-lh-55 border-radius-100px d-inline-block mb-25px">About
                        Company</span>
                    <h3 class="fw-600 text-dark-gray ls-minus-2px alt-font sm-w-80 xs-w-100 mx-auto sm-mb-20px">
                        PT Solusi Energy Nusantara (SENA)
                    </h3>
                    <p>
                        didirikan pada tahun 2015, merupakan anak perusahaan PT PGAS
                        Solution yang berfokus pada penyediaan layanan jasa engineering di
                        industri oil dan gas. Dengan keahlian dan pengalamannya yang luas,
                        SENA hadir sebagai mitra terpercaya bagi perusahaan-perusahaan di
                        sektor energi untuk menyelesaikan berbagai proyek strategis.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-solitude-blue">
        <div class="container">
            <div class="row justify-content-center mb-3">
                <div class="col-xl-5 col-lg-6 col-sm-8 text-center"
                    data-anime='{ "el": "childs", "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                    <h3 class="alt-font text-dark-gray fw-600 ls-minus-2px">
                        Building a Brighter Future
                    </h3>
                </div>
            </div>
            <div class="row justify-content-center"
                data-anime='{ "el": "childs", "perspective": [1200,1200], "translateY": [30, 0], "scale": [1.05, 1], "rotateX": [30, 0], "opacity": [0,1], "duration": 800, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <!-- start fancy text box item -->
                <div class="col-lg-6 col-md-8 fancy-text-box-style-02 mb-30px">
                    <div
                        class="feature-box feature-box-left-icon-middle h-100 bg-white hover-box dark-hover border-radius-6px ps-4 pe-4 pt-9 pb-9 box-shadow-extra-large box-shadow-extra-large-hover overflow-hidden">
                        <div class="feature-box-icon ms-40px me-40px lg-ms-15px lg-me-15px">
                            <h2 class="alt-font text-dark-gray fw-700 ls-minus-1px mb-0">
                                Visi
                            </h2>
                        </div>
                        <div
                            class="feature-box-content border-start border-color-extra-medium-gray ps-40px pe-40px lg-ps-15px lg-pe-15px last-paragraph-no-margin">
                            <p class="text-light-opacity">
                                Solusi terbaik engineering dan inspeksi berbasis teknologi di
                                bidang Energi.
                            </p>
                        </div>
                        <div class="feature-box-overlay bg-base-color"></div>
                    </div>
                </div>
                <!-- end fancy text box item -->
                <!-- start fancy text box item -->
                <div class="col-lg-6 col-md-8 fancy-text-box-style-02 mb-30px">
                    <div
                        class="feature-box feature-box-left-icon-middle h-100 bg-white hover-box dark-hover border-radius-6px ps-4 pe-4 pt-9 pb-9 box-shadow-extra-large box-shadow-extra-large-hover overflow-hidden">
                        <div class="feature-box-icon ms-40px me-40px lg-ms-15px lg-me-15px">
                            <h2 class="alt-font text-dark-gray fw-700 ls-minus-1px mb-0">
                                Misi
                            </h2>
                        </div>
                        <div
                            class="feature-box-content border-start border-color-extra-medium-gray ps-40px pe-40px lg-ps-15px lg-pe-15px last-paragraph-no-margin">
                            <p class="text-light-opacity">
                                Memberikan solusi engineering yang handal dan solusi inspeksi
                                yang akurat dan terpercaya di bidang energi Menciptakan
                                pertumbuhan yang stabil dan menguntungkan untuk stakeholder
                            </p>
                            </p>
                        </div>

                        <div class="feature-box-overlay bg-base-color"></div>
                    </div>
                </div>
                <!-- end fancy text box item -->
            </div>
        </div>
    </section>

    <section class="big-section position-relative">
        <div id="particles-style-01" class="position-absolute h-100 top-0 left-0 w-100" data-particle="true"
            data-particle-options='{"particles":{"number":{"value":25,"density":{"enable":true,"value_area":800}},"color":{"value":"#115cfa"},"shape":{"type":"circle","stroke":{"width":0,"color":"#000000"},"polygon":{"nb_sides":5},"image":{"src":"img/github.svg","width":100,"height":100}},"opacity":{"value":1,"random":false,"anim":{"enable":false,"speed":1,"opacity_min":0.1,"sync":false}},"size":{"value":4,"random":true,"anim":{"enable":false,"speed":40,"size_min":0.1,"sync":false}},"line_linked":{"enable":false,"distance":150,"color":"#ffffff","opacity":0.4,"width":1},"move":{"enable":true,"speed":6,"direction":"none","random":false,"straight":false,"out_mode":"out","bounce":false,"attract":{"enable":false,"rotateX":600,"rotateY":1200}}},"interactivity":{"detect_on":"canvas","events":{"onhover":{"enable":true,"mode":"repulse"},"onclick":{"enable":true,"mode":"push"},"resize":true},"modes":{"grab":{"distance":400,"line_linked":{"opacity":1}},"bubble":{"distance":400,"size":40,"duration":2,"opacity":8,"speed":3},"repulse":{"distance":200,"duration":0.4},"push":{"particles_nb":4},"remove":{"particles_nb":2}}},"retina_detect":true}'>
        </div>
        <div class="container">
            <div class="row justify-content-center align-items-center mb-6 text-center text-lg-start">
                <div class="row justify-content-center mb-3">
                    <div class="col-xl-5 col-lg-6 col-sm-8 text-center"
                        data-anime='{ "el": "childs", "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                        <h3 class="alt-font text-dark-gray fw-600 ls-minus-2px">
                            DEWAN KOMISARIS DAN DIREKSI
                        </h3>
                    </div>
                </div>
                {{-- <div class="col-xxl-4 col-lg-5 col-md-8 col-sm-10 last-paragraph-no-margin"
                    data-anime='{ "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                    <p>Lorem ipsum dolor to consectetur adipiscing elit eiusmod tempor incididunt labore ipsum.</p>
                </div> --}}
            </div>
            <div class="row row-cols-1 row-cols-lg-3 row-cols-md-2 justify-content-center">
                <!-- start team member item -->
                <div class="col text-center team-style-04 md-mb-50px">
                    <a href="#modal-popup" class="modal-popup">

                        <figure class="mb-0 position-relative">
                            <img src="https://linierdemo.my.id/assets/image/fuad.png" class="border-radius-10px"
                                alt="" />
                            <figcaption class="w-100 ps-50px pe-50px">
                                <div class="position-relative p-35px lg-p-25px pb-0 border-radius-10px bg-base-color">
                                    <div class="social-icon mb-20px">
                                        <a href="https://www.facebook.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-facebook-f icon-small"></i></a>
                                        <a href="https://www.instagram.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-instagram icon-small"></i></a>
                                        <a href="https://www.twitter.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-twitter icon-small"></i></a>
                                    </div>
                                    <div class="fs-19 fw-500 text-white lh-20">FUAD HASYIM</div>
                                    <span class="text-white opacity-7 d-inline-block fs-15">Direktur Utama</span>
                                </div>
                            </figcaption>
                        </figure>
                    </a>
                </div>
                <!-- end team member item -->
                <!-- start team member item -->
                <div class="col text-center team-style-04 md-mb-50px">
                    <a href="#modal-popup" class="modal-popup">

                        <figure class="mb-0 position-relative">
                            <img src="https://linierdemo.my.id/assets/image/suhartawan.png" class="border-radius-10px"
                                alt="" />
                            <figcaption class="w-100 ps-50px pe-50px">
                                <div class="position-relative p-35px lg-p-25px pb-0 border-radius-10px bg-base-color">
                                    <div class="social-icon mb-20px">
                                        <a href="https://www.facebook.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-facebook-f icon-small"></i></a>
                                        <a href="https://www.instagram.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-instagram icon-small"></i></a>
                                        <a href="https://www.twitter.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-twitter icon-small"></i></a>
                                    </div>
                                    <div class="fs-19 fw-500 text-white lh-20">SUHARTAWAN
                                        BAMBANG</div>
                                    <span class="text-white opacity-7 d-inline-block fs-15">Direktur Teknik dan
                                        Komersialc</span>
                                </div>
                            </figcaption>
                        </figure>
                    </a>
                </div>
                <!-- end team member item -->
                <!-- start team member item -->
                <div class="col text-center team-style-04">
                    <a href="#modal-popup" class="modal-popup">
                        <figure class="mb-0 position-relative">
                            <img src="https://linierdemo.my.id/assets/image/su.png" class="border-radius-10px"
                                alt="" />

                            <figcaption class="w-100 ps-50px pe-50px">
                                <div class="position-relative p-35px lg-p-25px pb-0 border-radius-10px bg-base-color">
                                    <div class="social-icon mb-20px">
                                        <a href="https://www.facebook.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-facebook-f icon-small"></i></a>
                                        <a href="https://www.instagram.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-instagram icon-small"></i></a>
                                        <a href="https://www.twitter.com/" target="_blank" class="text-white"><i
                                                class="fa-brands fa-twitter icon-small"></i></a>
                                    </div>
                                    <div class="fs-19 fw-500 text-white lh-20">SUDJONO</div>
                                    <span class="text-white opacity-7 d-inline-block fs-15">Komisaris Utama</span>
                                </div>
                            </figcaption>
                        </figure>
                    </a>
                </div>
                <!-- end team member item -->
            </div>
        </div>
    </section>


    <div id="modal-popup" class="mfp-hide subscribe-popup">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-9 col-md-10 bg-white">
                    <div class="row position-relative box-shadow-quadruple-large">
                        <div class="col-lg-4 cover-background md-h-400px xs-h-300px"
                            style="background-image: url('https://linierdemo.my.id/assets/image/fuad.png');">
                        </div>
                        <div class="col-lg-8 newsletter-popup p-8 pt-10 pb-10 lg-p-5 md-p-6 xs-p-8 position-relative">
                            <span class="d-block fs-24 fw-600 alt-font text-dark-gray mb-15px">Fuad Hasyim</span>
                            <p style="font-size:15px;">
                                Fuad has more than 27 years Experiences in project/ engineering management. He is expert
                                in managing multi billion project for various industry such as oil and gas,
                                petrochemical, refinery and power generation. The last project he has involved is with
                                KBR on Gorgon LNG project for Chevron in Western of Australia where he was spent 3.5
                                years services as Deputy Engineering Manager/ Senior Project Engineer.

                            </p>

                            <div class="col-12">
                                <span class="d-block fs-24 fw-600 alt-font text-dark-gray mb-15px">Education and
                                    Qualification</span>

                                <ul class="p-0 m-0 list-style-02" style="font-size:15px;">
                                    <li>
                                        2021 - Direktur Utama - PT Solusi Energy Nusantara
                                    </li>
                                    <li>
                                        2021 - President Director - PT Harmoni Energi Persada
                                    </li>
                                    <li>
                                        2020 - Executive Vice President - TRIPATRA
                                    </li>
                                    <li>
                                        2018 - CEO & President Director - PT Harmoni Energi Persada
                                    </li>
                                    <li>
                                        2016 - President Director - PT KBR Indonesia
                                    </li>
                                    <li>
                                        2013 - Head of Structural and Marine Department - KBR, Inc.
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <button title="Close (Esc)" type="button" class="mfp-close text-dark-gray"></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-layout>
