<x-layout>

    <x-slot:title>
        {{ $title }}
    </x-slot:title>

    <!-- start section -->
    <section>
        <div class="container">
            <div class="row justify-content-center text-center text-lg-start"
                data-anime='{ "el": "childs", "translateX": [50, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 100, "easing": "easeOutQuad" }'>
                <div class="col-lg-6 md-mb-25px">
                    <h1 class="alt-font fw-600 text-dark-gray mb-0 ls-minus-1px shadow-none" data-shadow-animation="true"
                        data-animation-delay="700">Perfect <span class="text-highlight">solutions<span
                                class="bg-base-color h-10px sm-h-8px bottom-20px md-bottom-17px opacity-5 separator-animation"></span></span>
                        for your business.</h1>
                </div>
                <div class="col-lg-5 offset-lg-1 last-paragraph-no-margin">
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit do eiusmod tempor incididunt ut labore et
                        dolore magna ut enim ad minim veniam nostrud exercitation.</p>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 justify-content-center counter-style-06"
                data-anime='{ "el": "childs", "translateX": [-50, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 100, "easing": "easeOutQuad" }'
                style="    margin-top: 50px;">
                <!-- start counter item -->
                <div class="col feature-box md-mb-50px xs-mb-30px">
                    <div class="feature-box-content">
                        <div class="counter-number text-yellow counter fs-120 fw-700 ls-minus-3px" data-speed="2000"
                            data-to="14"></div>
                        <span class="counter-title fs-24 fw-500 text-dark-gray ls-minus-1px">Engineering
                            Experiences</span>
                    </div>
                </div>
                <!-- end counter item -->
                <!-- start counter item -->
                <div class="col feature-box md-mb-50px xs-mb-30px">
                    <div class="feature-box-content">
                        <div class="counter-number text-yellow counter fs-120 fw-700 ls-minus-3px" data-speed="2000"
                            data-to="11"></div>
                        <span class="counter-title fs-24 fw-500 text-dark-gray ls-minus-1px">Survey Experiences</span>
                    </div>
                </div>
                <!-- end counter item -->
                <!-- start counter item -->
                <div class="col feature-box xs-mb-30px">
                    <div class="feature-box-content">
                        <div class="counter-number text-yellow counter fs-120 fw-700 ls-minus-3px" data-speed="2000"
                            data-to="11"></div>
                        <span class="counter-title fs-24 fw-500 text-dark-gray ls-minus-1px">Inspection
                            Experiences</span>
                    </div>
                </div>
                <!-- end counter item -->
                <!-- start counter item -->
                <div class="col feature-box">
                    <div class="feature-box-content last-paragraph-no-margin">
                        <div class="counter-number text-yellow counter fs-120 fw-700 ls-minus-3px" data-speed="2000"
                            data-to="11"></div>
                        <span class="counter-title fs-24 fw-500 text-dark-gray ls-minus-1px">Consultant
                            Experiences</span>
                    </div>
                </div>
                <!-- end counter item -->
            </div>
        </div>
    </section>
    <!-- end section -->
    <!-- start section -->
    <section class="overflow-hidden bg-regal-blue position-relative border-radius-6px lg-border-radius-0px z-index-0">
        <img src="https://craftohtml.themezaa.com/images/demo-corporate-bg-01.png"
            class="position-absolute top-minus-150px left-minus-30px z-index-minus-1"
            data-bottom-top="transform: rotate(0deg) translateY(0)"
            data-top-bottom="transform:rotate(-20deg) translateY(0)" alt="" />
        <div class="container">
            <div class="row align-items-center mb-5 sm-mb-30px text-center text-lg-start"
                data-anime='{ "el": "childs", "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay":0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <div class="col-lg-5 md-mb-30px">
                    <h3 class="text-dark-gray fw-700 ls-minus-2px mb-0" style="color: #fff">
                        Layanan Kami
                    </h3>
                </div>
                <div class="col-lg-4 offset-xl-1 last-paragraph-no-margin md-mb-30px">
                    <p>
                        Kami memberikan layanan jasa engineering di industri oil dan gas
                        yang mencakup bidang pipeline, mechanical, electrical, geodetic,
                        civil, process dan telemetry
                    </p>
                </div>
                <div class="col-xl-2 col-lg-3 d-flex justify-content-center">
                    <!-- start slider navigation -->
                    <div
                        class="slider-one-slide-prev-1 icon-small text-dark-gray swiper-button-prev slider-navigation-style-04 bg-white box-shadow-large">
                        <i class="fa-solid fa-arrow-left"></i>
                    </div>
                    <div
                        class="slider-one-slide-next-1 icon-small text-dark-gray swiper-button-next slider-navigation-style-04 bg-white box-shadow-large">
                        <i class="fa-solid fa-arrow-right"></i>
                    </div>
                    <!-- end slider navigation -->
                </div>
            </div>
            <div class="row align-items-center"
                data-anime='{ "opacity": [0,1], "duration": 600, "delay":0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <div class="col-12">
                    <div class="outside-box-right-20 sm-outside-box-right-0">
                        <div class="swiper magic-cursor slider-one-slide"
                            data-slider-options='{ "slidesPerView": 1, "spaceBetween": 30, "loop": true, "navigation": { "nextEl": ".slider-one-slide-next-1", "prevEl": ".slider-one-slide-prev-1" }, "autoplay": { "delay": 4000, "disableOnInteraction": false }, "keyboard": { "enabled": true, "onlyInViewport": true }, "breakpoints": { "1200": { "slidesPerView": 4 }, "992": { "slidesPerView": 3 }, "768": { "slidesPerView": 2 }, "320": { "slidesPerView": 1 } }, "effect": "slide" }'>
                            <div class="swiper-wrapper">
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="#modal-popup"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Consulting.jpg"
                                                    alt="" /></a>

                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="#modal-popup"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Consulting</a>
                                                <p>
                                                    Kami memprediksi, mengendalikan kinerja dan menuntun
                                                    proyek sesuai dengan kontrak
                                                </p>
                                            </div>
                                            <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="#modal-popup"
                                                    class="modal-popup btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Detail</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="#modal-popup"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Engineering_Design.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="#modal-popup"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Engineering
                                                    Design</a>
                                                <p>
                                                    Keahlian kami untuk menyusun dokumen engineering
                                                    design yang mengacu pada conceptual design
                                                </p>
                                            </div>
                                            <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="#modal-popup"
                                                    class="modal-popup btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Detail</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="#modal-popup"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Inspeksi_dan_Pengujian_Teknis.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="#modal-popup"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Inspeksi
                                                    dan Pengujian Teknis</a>
                                                <p>
                                                    Keahlian kami dalam inspeksi dan pengujian teknis,
                                                    commissioning, dan pekerjaan pasca operasi.
                                                </p>
                                            </div>
                                            <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="#modal-popup"
                                                    class="modal-popup btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Detail</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="#modal-popup"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Survei_dan_Penelitian_Teknis.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="#modal-popup"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Survei
                                                    dan Penelitian Teknis</a>
                                                <p>
                                                    PT Solusi Energy Nusantara memiliki keahlian dalam
                                                    bidang survei dan penelitian teknis
                                                </p>
                                            </div>
                                            <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="#modal-popup"
                                                    class="modal-popup btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Detail</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="#modal-popup"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Consulting.jpg"
                                                    alt="" /></a>

                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="#modal-popup"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Consulting</a>
                                                <p>
                                                    Kami memprediksi, mengendalikan kinerja dan menuntun
                                                    proyek sesuai dengan kontrak
                                                </p>
                                            </div>
                                            <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="#modal-popup"
                                                    class="modal-popup btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Detail</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="#modal-popup"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Engineering_Design.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="#modal-popup"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Engineering
                                                    Design</a>
                                                <p>
                                                    Keahlian kami untuk menyusun dokumen engineering
                                                    design yang mengacu pada conceptual design
                                                </p>
                                            </div>
                                            <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="#modal-popup"
                                                    class="modal-popup btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Detail</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="#modal-popup"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Inspeksi_dan_Pengujian_Teknis.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="#modal-popup"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Inspeksi
                                                    dan Pengujian Teknis</a>
                                                <p>
                                                    Keahlian kami dalam inspeksi dan pengujian teknis,
                                                    commissioning, dan pekerjaan pasca operasi.
                                                </p>
                                            </div>
                                            <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="#modal-popup"
                                                    class="btn btn-base-color btn-very-small d-table d-lg-inline-block lg-mb-15px md-mx-auto modal-popup text-transform-none">
                                                    <span>
                                                        <span class="btn-text">Detail</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                                <!-- start slider item -->
                                <div class="swiper-slide">
                                    <!-- start services box style -->
                                    <div
                                        class="services-box-style-03 last-paragraph-no-margin border-radius-6px overflow-hidden">
                                        <div class="position-relative">
                                            <a href="#modal-popup"><img
                                                    src="{{ URL::asset('assets') }}/image/LayananSegmen_Survei_dan_Penelitian_Teknis.jpg"
                                                    alt="" /></a>
                                        </div>
                                        <div class="bg-white">
                                            <div class="ps-25px pe-25px pt-30px pb-30px text-center">
                                                <a href="#modal-popup"
                                                    class="d-inline-block fs-18 fw-700 text-dark-gray mb-5px">Survei
                                                    dan Penelitian Teknis</a>
                                                <p>
                                                    PT Solusi Energy Nusantara memiliki keahlian dalam
                                                    bidang survei dan penelitian teknis
                                                </p>
                                            </div>
                                            <div
                                                class="d-flex justify-content-center border-top border-color-extra-medium-gray pt-20px pb-20px ps-50px pe-50px position-relative text-center">
                                                <a href="#modal-popup"
                                                    class="modal-popupmodal-popup btn btn-link btn-hover-animation-switch btn-medium fw-700 text-dark-gray text-uppercase">
                                                    <span>
                                                        <span class="btn-text">Detail</span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                        <span class="btn-icon"><i
                                                                class="fa-solid fa-arrow-right"></i></span>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end services box style -->
                                </div>
                                <!-- end slider item -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-60px">
                <div class="col-12 text-center">
                    <i
                        class="bi bi-envelope text-white d-inline-block align-middle icon-extra-medium me-10px md-m-5px"></i>
                    <div class="fs-18 text-white d-inline-block align-middle">
                        Save your precious time and effort spent for finding a solution.
                        <a href="demo-corporate-contact.html" class="text-white text-decoration-line-bottom">Contact
                            us now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- end section -->
    <!-- start section -->
    <section class="overflow-hidden big-section">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 lg-mb-45px xs-mb-30px text-sm-start text-center">
                    <span class="fs-70 xs-fs-50 fw-700 text-dark-gray mb-0 ls-minus-2px">Hear from clients.</span>
                </div>
                <div class="col-xl-8">
                    <div class="outside-box-right-45 sm-outside-box-right-0">
                        <div class="swiper magic-cursor"
                            data-slider-options='{ "slidesPerView": 1, "spaceBetween": 60, "loop": true, "parallax": true, "speed": 1200, "pagination": { "el": ".slider-one-slide-pagination", "clickable": true, "dynamicBullets": false }, "navigation": { "nextEl": ".slider-one-slide-next-2", "prevEl": ".slider-one-slide-prev-2" }, "autoplay": { "delay": 5000, "disableOnInteraction": false }, "keyboard": { "enabled": true, "onlyInViewport": true }, "breakpoints": { "992": { "slidesPerView": 4 }, "768": { "slidesPerView": 2 }, "320": { "slidesPerView": 1 } }, "effect": "slide" }'>
                            <div class="swiper-wrapper testimonials-style-13">
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Herman miller</span>
                                    <p class="fs-22 lh-36 text-dark-gray">From the day one, Themezaa has delivered all
                                        possible outcomes as demanded. I must say that all the developers are dedicated.
                                    </p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Shoko mugikura</span>
                                    <p class="fs-22 lh-36 text-dark-gray">Theme is beautiful, although it takes some
                                        time to figure out where to edit what. But support is very quick and helpful
                                        theme.</p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Matthew taylor</span>
                                    <p class="fs-22 lh-36 text-dark-gray">They are very good with communication,
                                        addressing the need and attentively making sure the customer is fully supported.
                                    </p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Leonel mooney</span>
                                    <p class="fs-22 lh-36 text-dark-gray">What an awesome theme and support team is
                                        very kind. Every element is designed pixel perfect, so it is really a modern
                                        theme.</p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Herman miller</span>
                                    <p class="fs-22 lh-36 text-dark-gray">From the day one, Themezaa has delivered all
                                        possible outcomes as demanded. I must say that all the developers are dedicated.
                                    </p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Shoko mugikura</span>
                                    <p class="fs-22 lh-36 text-dark-gray">Theme is beautiful, although it takes some
                                        time to figure out where to edit what. But support is very quick and helpful
                                        theme.</p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Matthew taylor</span>
                                    <p class="fs-22 lh-36 text-dark-gray">They are very good with communication,
                                        addressing the need and attentively making sure the customer is fully supported.
                                    </p>
                                </div>
                                <!-- end review item -->
                                <!-- start review item -->
                                <div class="swiper-slide text-sm-start text-center last-paragraph-no-margin"
                                    data-swiper-parallax="700">
                                    <span class="fs-15 fw-800 text-dark-gray text-uppercase mb-10px d-block ls-1px">@
                                        Leonel mooney</span>
                                    <p class="fs-22 lh-36 text-dark-gray">What an awesome theme and support team is
                                        very kind. Every element is designed pixel perfect, so it is really a modern
                                        theme.</p>
                                </div>
                                <!-- end review item -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div
                                class="separator-line-5px w-100 bg-extra-medium-gray mt-45px mb-45px xs-mt-30px xs-mb-30px">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-4 xs-mb-30px">
                            <div class="d-flex justify-content-center justify-content-sm-start">
                                <!-- start slider navigation -->
                                <div class="slider-one-slide-prev-2 text-black swiper-button-prev slider-navigation-style-04 bg-yellow h-65px w-65px"
                                    tabindex="0" role="button" aria-label="Previous slide"><i
                                        class="fa-solid fa-arrow-left"></i></div>
                                <div class="slider-one-slide-next-2 text-black swiper-button-next slider-navigation-style-04 bg-yellow h-65px w-65px"
                                    tabindex="0" role="button" aria-label="Next slide"><i
                                        class="fa-solid fa-arrow-right"></i></div>
                                <!-- end slider navigation -->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row position-relative clients-style-08"
                data-anime='{ "translateX": [0, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                <div class="col swiper text-center feather-shadow"
                    data-slider-options='{ "slidesPerView": 2, "spaceBetween":100, "speed": 6000, "loop": true, "pagination": { "el": ".slider-four-slide-pagination-2", "clickable": false }, "allowTouchMove": false, "autoplay": { "delay":0, "disableOnInteraction": false }, "navigation": { "nextEl": ".slider-four-slide-next-2", "prevEl": ".slider-four-slide-prev-2" }, "keyboard": { "enabled": true, "onlyInViewport": true }, "breakpoints": { "1200": { "slidesPerView": 6 }, "992": { "slidesPerView": 4 }, "768": { "slidesPerView": 3 } }, "effect": "slide" }'>
                    <div class="swiper-wrapper marquee-slide">

                        <div class="swiper-slide">
                            <a href="#"><img
                                    src="https://pt-sena.co.id/images/client/16_logo_logo_client-07.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="https://pt-sena.co.id/images/client/6_logo_logo_client-03.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="https://pt-sena.co.id/images/client/7_logo_Picture2.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img src="https://pt-sena.co.id/images/client/5_logo_logo_client-04.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img
                                    src="https://pt-sena.co.id/images/client/18_logo_logo_client-05.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img
                                    src="https://pt-sena.co.id/images/client/17_logo_logo_client-06.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"><img
                                    src="https://pt-sena.co.id/images/client/16_logo_logo_client-07.png"
                                    class="h-150px xs-h-30px" alt="" /></a>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end section -->
    <style>
        #modal-popup {
            border-radius: 10px;
            /* Adjust the radius as needed */
        }
    </style>
    <div id="modal-popup" class="mfp-hide subscribe-popup rounded-10">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-9 col-md-10 bg-white">
                    <div class="row position-relative box-shadow-quadruple-large">
                        <div class="col-lg-6 cover-background md-h-400px xs-h-300px"
                            style="background-image: url('{{ URL::asset('assets') }}/image/LayananSegmen_Consulting.jpg');">
                        </div>
                        <div class="col-lg-6 newsletter-popup p-8 pt-10 pb-10 lg-p-5 md-p-6 xs-p-8 position-relative">
                            <h4 class="d-inline-block alt-font ls-minus-1px fw-700 text-dark-gray mb-15px">
                                Consulting
                            </h4>
                            <p>
                                Dalam pengelolaan proyek, PT Solusi Energy Nusantara
                                (SENA) mampu memprediksi, mengendalikan kinerja dan
                                menuntun proyek sesuai dengan kontrak. Layanan
                                konsultasi Project Management yang kami lakukan antara
                                lain:
                            </p>
                            <ul class="p-0 list-style-01 fw-500 mb-40px" style="">
                                <li class="border-color-transparent-dark-light pt-10px pb-10px text-dark-gray">
                                    Project Management Consultancy (PMC)
                                </li>
                                <li class="border-color-transparent-dark-light pt-10px pb-10px text-dark-gray">
                                    Project Supervision
                                </li>
                                <li class="border-color-transparent-dark-light pt-10px pb-10px text-dark-gray">
                                    Technical Assistance Services (TAS)
                                </li>
                                <li class="border-color-transparent-dark-light pt-10px pb-10px text-dark-gray">
                                    Studi/Kajian di bidang energi
                                </li>
                            </ul>
                        </div>
                        <button title="Close (Esc)" type="button" class="mfp-close text-dark-gray"></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-layout>
